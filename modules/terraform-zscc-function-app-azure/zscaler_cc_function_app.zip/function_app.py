import os
import json
import azure.functions as func

from lib.zs_logger import zslogger
from health_monitor import HealthMonitor
from resource_sync import ResourceSynchronizer

app = func.FunctionApp()

def parse_env_vars():
    subscription_id = os.environ.get('SUBSCRIPTION_ID')
    managed_identity = os.environ.get('MANAGED_IDENTITY')
    resource_group = os.environ.get('RESOURCE_GROUP')
    certificate_verify = os.environ.get('CERTIFICATE_VERIFY', 'true')
    vmss_names = os.environ.get('VMSS_NAME')
    if not subscription_id or not managed_identity or not resource_group or not vmss_names:
        zslogger.error(
            f"Missing ENV Varibales. SUBSCRIPTION_ID: {subscription_id}, MANAGED_IDENTITY: {managed_identity}, " 
            f"RESOURCE_GROUP: {resource_group}, VMSS_NAME: {vmss_names}"
        )
        return None
    try:
        vmss_names = json.loads(vmss_names)
    except Exception as e:
        zslogger.error(f"Failed to load VMSS_NAME ENV variable. Expecting this to be a json list of VMSS names. {vmss_names}")
        return None
    
    try:
        subscription_id = subscription_id.split("/")[2]
    except Exception as e:
        zslogger.error(
            f"Failed to load SUBSCRIPTION_ID ENV variable. Expecting this to be in the format /subscriptions/<subscription_id>"
        )
        return None

    if certificate_verify == 'false':
        certificate_verify = False
    else:
        certificate_verify = True

    zslogger.info(
        f"subscription_id: {subscription_id}, managed_identity: {managed_identity}, resource_group: {resource_group}, "
        f"vmss_names: {vmss_names}, certificate_verify: {certificate_verify}"
    )
    return (subscription_id, managed_identity, resource_group, vmss_names, certificate_verify)


def process_health_monitor(myTimer: func.TimerRequest) -> None:
    zslogger.info('Health monitoring triggered.')

    resp = parse_env_vars()
    if resp is None:
        return
    subscription_id, managed_identity, resource_group, vmss_names, _ = resp

    try:
        health_mon_obj = HealthMonitor.create_health_monitor_instance(
            subscription_id=subscription_id,
            managed_identity=managed_identity,
            resource_group=resource_group,
        )
        health_mon_obj.handle_vmss_cc_health(vmss_names=vmss_names)
    except Exception as e:
        zslogger.error(f"Failed to monitor health: {str(e)}")


def process_synchronize_cloud_resources(myTimer: func.TimerRequest) -> None:
    zslogger.info(f"Resource clean up triggered.")

    resp = parse_env_vars()
    if resp is None:
        return
    subscription_id, managed_identity, resource_group, vmss_names, certificate_verify = resp

    try:
        resource_sync_obj = ResourceSynchronizer.create_resource_synchronizer_instance(
            subscription_id=subscription_id,
            managed_identity=managed_identity,
            resource_group=resource_group,
            certificate_verify=certificate_verify
        )
        resource_sync_obj.handle_resource_synchronization(vmss_names=vmss_names)
    except Exception as e:
        zslogger.error(f"Failed to synchronize resources: {str(e)}")


@app.timer_trigger(schedule="0 * * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
def healthMonitor(myTimer: func.TimerRequest) -> None:
    process_health_monitor(myTimer)


@app.timer_trigger(schedule="0 */30 * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
def synchronizeCloudResources(myTimer: func.TimerRequest) -> None:
    process_synchronize_cloud_resources(myTimer)


