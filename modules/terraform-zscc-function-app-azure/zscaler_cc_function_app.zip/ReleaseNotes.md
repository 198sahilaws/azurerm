Zscaler Azure Function functionality Release Notes
Version 1.0.1
Enhancements and Fixes
Added a fix to resolve a bug where Cloud Connectors were being removed from their Cloud Connector Groups in the Zscaler Portal while they were booting up. This issue occured when the Resource Synchronization function was triggered at the same time when the Cloud Connector was booting up.